#!/bin/bash

hostname
df -h

